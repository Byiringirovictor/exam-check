const express = require('express');
const router = express.Router();
const userController = require('../controllers/UserController');

router.post('/addStudents',userController.registerUser);
router.post('/login',userController.loginUser);
router.post('/courseRegister', userController.courseRegister);
router.get('/getCourses', userController.getCourses);
router.get('/getCourseById/:c_id', userController.getCourseById);
router.delete('/deleteCourse/:c_id', userController.deleteCourse);
router.put('/updateCourse/:c_id', userController.updateCourse);

module.exports = router;