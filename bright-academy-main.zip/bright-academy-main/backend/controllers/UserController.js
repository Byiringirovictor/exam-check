const db = require('../database/db');

const registerUser = (req, res) =>{
    const {username,email,password} = req.body;
    const sql = 'INSERT INTO students(username,email,password) VALUES(?,?,?)';
    db.query(sql,[username,email,password],
        (err,result)=>{
            if(err) throw err;
            console.log("Student registered");
            res.send(result);
        }
    )
}

const loginUser = (req, res) => {
    const { email, password } = req.body;

    const sql = 'SELECT * FROM students WHERE email = ? AND password = ?';
    db.query(sql, [email, password], (err, results) => {
        if (err) {
            console.error("Login error:", err);
            return res.status(500).send({ message: "Server error" });
        }
        if (results.length > 0) {
            res.send({ success: true, message: "Login successful!" });
        } else {
            res.status(401).send({ success: false, message: "Invalid email or password" });
        }
    });
};

const courseRegister = (req, res) =>{
    const {c_name,c_code,c_level} = req.body;

    const sql = "INSERT INTO courses(course_name,course_code,course_level) VALUES(?,?,?)";
    db.query(sql,[c_name,c_code,c_level],(error,result)=>{
        if(error){
            console.log("Registration fails");
        }
        res.send({success: true, message: "Course registered!"});
    });
}

const getCourses = (req,res) =>{
    const sql = "SELECT * FROM courses";
    db.query(sql,(error, results)=>{
        if(error){
            console.log("Error occured!",error);
        }
        res.send(results);            
    });
}

const deleteCourse = (req,res)=>{
    const {c_id} = req.params;
    const sql = "DELETE FROM courses WHERE c_id = ?";

    db.query(sql,[c_id], (error, result)=>{
        if(error){
            console.log("Delete Error.");
        }
        res.send({success: true, message: "Course deleted successfully."});

    })
}

const updateCourse = (req, res) =>{
    const {c_id} = req.params;
    const {c_name,c_code,c_level} = req.body;

    const sql = "UPDATE courses SET course_name = ?, course_code = ?, course_level= ? WHERE c_id=?";
    db.query(sql, [c_name,c_code,c_level,c_id], (err, result)=>{
        if(err){
            console.log(err);
        }
        res.send({success: true, message: "Course updated successfully!"});
    })
}

const getCourseById = (req, res) => {
    const { c_id } = req.params;
    const sql = 'SELECT * FROM courses WHERE c_id = ?';
  
    db.query(sql, [c_id], (err, results) => {
      if (err) {
        console.error('Fetch-by-ID error:', err);
      }
      res.send(results[0]);         
    });
  };

module.exports = {registerUser, loginUser, courseRegister, getCourses, deleteCourse, updateCourse, getCourseById};