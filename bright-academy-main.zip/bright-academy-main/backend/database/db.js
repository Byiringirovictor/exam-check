const mysql = require('mysql2');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database:"academy",
    port:3306
});

db.connect(error => {
    if(error) throw error;
    console.log("Mysql connected.");
});

module.exports = db;