import './App.css';
import Home from './home';
import {BrowserRouter as Router,Routes, Route} from 'react-router-dom';
import NavBar from './pages/NavBar';
import Registration from './pages/Registration';
import Login from './pages/Login';
import Dashboard from './pages/dashboard';
import CoursePage from './pages/coursePage';
import UpdatedCourse from './pages/updateCourse';

function App() {
  return (
    <Router>
      <NavBar/>
      <Routes>
        <Route path='/' element={<Home/>} />
        <Route path="/registration" element={<Registration/>} />
        <Route path="/login" element={<Login/>} />
        <Route path="/dashboard" element={<Dashboard/>} />
        <Route path="/coursePage" element={<CoursePage/>} />
        <Route path="/updateCourse/:c_id" element={<UpdatedCourse/>} />
      </Routes>
    </Router>
  
  );
}

export default App;
