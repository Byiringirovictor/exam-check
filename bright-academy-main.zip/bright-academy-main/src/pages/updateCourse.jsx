import React,{useEffect, useState} from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from 'axios';

function UpdatedCourse(){
    const [c_name, setCname] = useState();
    const [c_code, setCcode] = useState();
    const [c_level, setClevel] = useState();

    const {c_id} = useParams();
    const navigate = useNavigate();

    useEffect(() =>{
        const fetchCourse = async() =>{
            try {
                const res = await axios.get(`http://localhost:5000/api/auth/getCourseById/${c_id}`);
                const course = res.data;
                setCname(course.course_name);
                setCcode(course.course_code);
                setClevel(course.course_level);
            } catch (error) {
                console.log('Failed to fetch course',error);
            }
        };

        fetchCourse();
    },[c_id]);

    const handleUpdate = async(e) =>{
        try {
            const res = await axios.put(`http://localhost:5000/api/auth/updateCourse/${c_id}`,
                {c_name,c_code,c_level,c_id}
            );
            if (res.data.success) {
                navigate('/dashboard');
                alert("Course updated!"); 
            } 
        } catch (error) {
            console.log("Error updating",error);
        }
    }

    return(
        <div>
            <h1>Update course</h1>
            <form onSubmit={handleUpdate}>
                <select name="c_name" onChange={(e)=>setCname(e.target.value)}>
                        <option value="{c_name}">{c_name}</option>
                        <option value="PHP">PHP</option>
                        <option value="Python">Python</option>
                        <option value="Java">Java</option>
                    </select><br/>
                    <select name="c_code" onChange={(e)=>setCcode(e.target.value)}>
                        <option value="{c_code}">{c_code}</option>
                        <option value="PHP01">PHP_01</option>
                        <option value="PY02">PY_02</option>
                        <option value="JV01">JV_01</option>
                    </select><br/>
                    <select name="c_level" onChange={(e)=>setClevel(e.target.value)}>
                        <option value="{c_name}">{c_level}</option>
                        <option value="3">Level 3</option>
                        <option value="4">Level 4</option>
                        <option value="5">Level 5</option>
                    </select><br/>
                <button type="submit">Update</button>
            </form>
        </div>
        
    );
}
export default UpdatedCourse;