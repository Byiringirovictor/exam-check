import React, { useState,useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

function Dashboard(){

    const [courses, setCourses] = useState([]);

    const getAllCourses = async () => {
        try {
            const res = await axios.get("http://localhost:5000/api/auth/getCourses");
            setCourses(res.data);
        } catch (error) {
            console.log(error);
        }
    };

    useEffect(()=>{
        getAllCourses();
    },[]);


    const handleDelete = async(c_id) =>{
        try {
            const res = await axios.delete(`http://localhost:5000/api/auth/deleteCourse/${c_id}`);
            alert('Course deleted');
            getAllCourses();
        } catch (error) {
            console.log(error);
            alert('Sorry Course not deleted!');

        }
    }

    return(
        <div>
            <h1>Welcome to the dashboard</h1><br/>
            <Link to="/coursePage">Register in course</Link>
            <div>
                <h2>list of Courses</h2>
                {courses.length === 0 ? (
                    <h3>No course found.</h3>
                ): (
                    <table border='1'>
                        <tr>
                            <th>No</th>
                            <th>Course Name</th>
                            <th>Course Code</th>
                            <th>Level</th>
                            <th colspan='2'>Action</th>
                        </tr>
                        {courses.map((course, index)=>(
                            <tr key={course.c_id}>
                                <td>{course.c_id}</td>
                                <td>{course.course_name}</td>
                                <td>{course.course_code}</td>
                                <td>{course.course_level}</td>
                                <td><button onClick={() => handleDelete(course.c_id)}>Delete</button></td>
                                <td><Link to={`/updateCourse/${course.c_id}`}>Update</Link></td>
                            </tr>
                        ))}
                    </table>
                )}
            </div>
        </div>
    );
}
export default Dashboard;