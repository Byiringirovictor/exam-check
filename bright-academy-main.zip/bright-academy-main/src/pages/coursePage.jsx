import React, { useState } from "react";
import axios from 'axios';
import { useNavigate } from "react-router-dom";

function CoursePage(){
    const [c_name, setCname] = useState();
    const [c_code, setCcode] = useState();
    const [c_level, setClevel] = useState();

    const navigate = useNavigate();

    const handleSubmit = async(event) => {
        try {
            const res = await axios.post("http://localhost:5000/api/auth/courseRegister",
                {c_name,c_code,c_level}
            );
            navigate('/dashboard');
            alert("Course registered successfully");
            
        } catch (error) {
            console.log(error);
            alert("Failed to register!");
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <select name="c_name" onChange={(e)=>setCname(e.target.value)}>
                    <option value="">Select course...</option>
                    <option value="PHP">PHP</option>
                    <option value="Python">Python</option>
                    <option value="Java">Java</option>
                </select><br/>
                <select name="c_code" onChange={(e)=>setCcode(e.target.value)}>
                    <option value="">Select code...</option>
                    <option value="PHP01">PHP_01</option>
                    <option value="PY02">PY_02</option>
                    <option value="JV01">JV_01</option>
                </select><br/>
                <select name="c_level" onChange={(e)=>setClevel(e.target.value)}>
                    <option value="">Select Level...</option>
                    <option value="3">Level 3</option>
                    <option value="4">Level 4</option>
                    <option value="5">Level 5</option>
                </select><br/>
            <button type="submit">Register</button>
        </form>
    );
}
export default CoursePage;