import React from "react";
import { useState } from "react";
import axios from 'axios';

function Registration() {
    const [username,setUsename] = useState("");
    const [email,setEmail] = useState("");
    const [password,setPassword] =useState("");

    const handleSubmit = async(e) =>{
        try {
            const res = await axios.post('http://localhost:5000/api/auth/addStudents',
                {username,email,password});
                alert('Student registered!');
        } catch (error) {
            console.log(error);
            alert('Sorry student Not registered!');
        }
    }
    return (
        <div>
            <h2>Registration</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="username" onChange={(e)=>setUsename(e.target.value)} placeholder="Username..." required /><br/>     
                <input type="email" name="email" onChange={(e)=>setEmail(e.target.value)} placeholder="Email..." required /><br/>
                <input type="password" name="password" onChange={(e)=>setPassword(e.target.value)} placeholder="Password..." required /><br/>
                <button>Register</button>    
            </form>
        </div>
    );
};

export default Registration;